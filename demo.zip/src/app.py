import sys
import os
import json
import io
import re
import time
import traceback
from pathlib import Path

# Third-party imports
import streamlit as st
import docx # type: ignore
from dotenv import load_dotenv

# --- Page Config ---
st.set_page_config(page_title="Writex - AI Document Formatter", page_icon="📝")

# --- Setup ---
load_dotenv()
root_path = Path(__file__).parent.parent
if str(root_path) not in sys.path:
    sys.path.append(str(root_path))

# --- Imports ---
from src.file_formatting.formatting import generate_report
from src.analysis.style_analyzer import StyleAnalyzer
from src.analysis.code_analyzer import CodeAnalyzer
from src.ai.report_generator import ReportGenerator

# --- ALL CONSTANTS ---
REPORT_SCHEMA = [
    {
        "title": "Introduction",
        "subsections": ["Project Overview", "Problem Statement", "Objectives", "Scope of the Project"]
    },
    {
        "title": "Literature Survey",
        "subsections": ["Existing Systems", "Limitations of Existing Systems", "Proposed System Comparison"]
    },
    {
        "title": "Methodology",
        "subsections": ["System Architecture", "Algorithm Details", "Data Flow Diagram Description", "Module Description"]
    },
    {
        "title": "Implementation",
        "subsections": ["Tools and Technologies", "Core Logic Implementation", "Code Structure"]
    },
    {
        "title": "Results and Discussion",
        "subsections": ["Performance Metrics", "Experimental Output", "Results Analysis"]
    },
    {
        "title": "Conclusion and Future Scope",
        "subsections": ["Conclusion", "Future Enhancements"]
    }
]

def run_formatting(text_content, api_key_val, style_name):
    # Keep lightweight formatting for Tabs 1 & 2
    from src.ai.structurer import structure_text
    if not api_key_val: return
    with st.spinner("Structuring..."):
        try:
             struct = structure_text(text_content, api_key=api_key_val, style_name=style_name)
             json_match = re.search(r'\[.*\]', struct, re.DOTALL)
             data = json.loads(json_match.group(0)) if json_match else []
             
             buf = io.BytesIO()
             generate_report(data, buf, style_name=style_name)
             st.download_button("Download", buf, "formatted.docx")
        except Exception as e:
            st.error(str(e))

# --- Main UI ---
st.title("📝 Writex: Academic Report Engine")
print("--- App Reloaded with Team Input ---")

with st.sidebar:
    api_key = st.text_input("Groq API Key", type="password", value=os.getenv("GROQ_API_KEY") or "")
    st.header("Formatting")
    style_opts = ["Standard", "IEEE", "APA"]
    sel_style = st.selectbox("Style", style_opts)

tab1, tab2, tab3 = st.tabs(["📄 Text", "📂 File", "🎓 Academic Report (Strict)"])

with tab1:
    txt = st.text_area("Raw Text")
    if st.button("Format Text"): run_formatting(txt, api_key, sel_style)

with tab2:
    upl = st.file_uploader("Upload Doc/Txt")
    if upl and st.button("Format File"):
        run_formatting("File content...", api_key, sel_style)

with tab3:
    st.header("Code to B.Tech Report")
    st.info("Generates a strict 6-chapter academic report with standard Front Matter.")
    
    col1, col2 = st.columns(2)
    with col1:
        proj_zip = st.file_uploader("Project ZIP", type=["zip"], key="project_zip")
        sample_rep = st.file_uploader("Upload Sample Report (PDF/DOCX)", type=["pdf", "docx"], help="Optional. Upload a sample to mimic its style.", key="sample_report")
        
    with col2:
        title = st.text_input("Project Title", value="My Project")
        degree = st.text_input("Degree", value="B.Tech Computer Science")
        university = st.text_input("University/College", value="My University")
        department = st.text_input("Department", value="Computer Science and Engineering")
        academic_year = st.text_input("Academic Year", value="2025–2026")
    
    st.subheader("Team & Signatories")
    c1, c2, c3 = st.columns(3)
    # Dynamic Team Inputs
    if 'team_count' not in st.session_state:
        st.session_state.team_count = 4 # Default to 4 as per user hint ("4 team members")

    def add_member():
        st.session_state.team_count += 1
    
    st.subheader("Team Members")
    team_names = []
    for i in range(st.session_state.team_count):
        # Use columns to align removing logic if needed, but for now just simple inputs
        tn = st.text_input(f"Member {i+1} Name", key=f"s_name_{i}")
        if tn: team_names.append(tn)
    
    st.button("➕ Add Team Member", on_click=add_member)
    
    # helper for context
    name = "\n".join(team_names)

    c2, c3 = st.columns(2)
    with c2:
        guide = st.text_input("Guide Name", placeholder="e.g. Prof. Anil Kumar")
    with c3:
        hod = st.text_input("HOD Name", placeholder="e.g. Dr. Sherly K K")
    
    principal = st.text_input("Principal Name", placeholder="e.g. Rev Dr. Jaison Paul CMI")

    if st.button("Generate Academic Report", type="primary"):
        if not api_key:
            st.error("🔒 Please enter your Groq API Key in the sidebar to proceed.")
        elif not proj_zip:
            st.error("📂 Please upload your Project ZIP file to generate the report.")
        elif not name.strip():
            st.error("👥 Please enter at least one Team Member name.")
        else:
            try:
                analyzer = CodeAnalyzer()
                with open("temp.zip", "wb") as f: f.write(proj_zip.getbuffer())
                with st.spinner("Analyzing Codebase..."):
                    summary = analyzer.analyze_zip("temp.zip")
                st.success(f"Analyzed {summary.total_files} files.")
                
                # Style Analysis
                style_guide = ""
                if sample_rep:
                    with st.spinner("Analyzing Sample Style (plus OCR if needed)..."):
                        sa = StyleAnalyzer(api_key=api_key)
                        # simple workaround for file-like object
                        # usage in st.file_uploader: .read(), .getvalue() etc.
                        # StyleAnalyzer expects file object for pdf/docs
                        
                        # specific extension
                        ext = sample_rep.name.split('.')[-1].lower()
                    raw_text = sa.extract_text(sample_rep, ext)
                    style_guide = sa.analyze_style(raw_text)
                    
                    # Extract specific sections for dynamic templating
                    sample_sections = sa.extract_specific_sections(sample_rep, ext)
                    st.toast("Style & Templates Extracted!", icon="🎨")

                gen = ReportGenerator(api_key)
                
                # Extract structured metadata from sample if provided to override defaults
                # Only use if we have sample text
                sample_metadata = {}
                if sample_rep:
                    with st.spinner("Extracting High-Level Metadata from Sample..."):
                        sample_metadata = gen.extract_metadata_from_sample(raw_text)
                        
                context = gen.derive_project_context(summary.to_json())
                
                # Pronoun logic: single student = I/my, team = We/our
                # If name isn't provided, see if sample threw us a list
                final_names = name.strip()
                if not final_names and sample_metadata.get("team_names"):
                     if isinstance(sample_metadata["team_names"], list):
                         final_names = "\n".join(sample_metadata["team_names"])
                     else:
                         final_names = str(sample_metadata["team_names"])
                
                # Determine mode based on line breaks
                name_count = len([n for n in final_names.split('\n') if n.strip()])
                pronoun_mode = "singular" if name_count <= 1 else "plural"
                
                context.update({
                    "title": title if title and title != "My Project" else sample_metadata.get("title", title), 
                    "student_name": final_names, 
                    "degree": degree if degree != "B.Tech Computer Science" else sample_metadata.get("degree", degree), 
                    "principal": principal or sample_metadata.get("principal", ""),
                    "guide": guide or sample_metadata.get("guide", ""),
                    "hod": hod or sample_metadata.get("hod", ""),
                    "university": university if university != "My University" else sample_metadata.get("university", university),
                    "department": department if department != "Computer Science and Engineering" else sample_metadata.get("department", department),
                    "academic_year": academic_year if academic_year != "2025–2026" else sample_metadata.get("academic_year", academic_year),
                    "pronoun_mode": pronoun_mode,
                    "problem_statement": context["problem_statement"],
                    "style_guide": style_guide,
                    "sample_report_provided": bool(sample_rep),
                    "sample_sections": sample_sections,
                    "has_test_files": len(summary.test_files) > 0,
                    "detailed_analysis": summary.detailed_analysis
                })
                
                # --- STRUCTURED GENERATION ---
                full_structure = []
                
                # 1. FRONT MATTER (TEMPLATE BASED)
                # Title Page
                full_structure.append({"type": "title", "text": context.get("title")})
                title_body = (
                    f"A PROJECT REPORT\n"
                    f"Submitted by\n"
                    f"{context.get('student_name')}\n"
                    f"In partial fulfillment for the award of the degree of\n"
                    f"{context.get('degree')}\n"
                    f"Department of {context.get('department')}\n"
                    f"{context.get('university')}\n"
                    f"{context.get('academic_year')}"
                )
                full_structure.append({"type": "paragraph", "text": title_body})
                full_structure.append({"type": "page_break", "text": ""})

                # Certificate
                full_structure.append({"type": "title", "text": "CERTIFICATE"}) 
                
                # If we have a sample certificate, the LLM logic in report_generator.py handles it
                cert_text = gen.fill_template("Certificate", context)
                full_structure.append({"type": "paragraph", "text": cert_text})
                
                # Only append signature block if we fell back to the strict string template 
                # (which doesn't have signature lines baked into the paragraph output usually, or we want to double append)
                # Actually, the base string template HAS the signature lines in textwrap, 
                # so let's use the explicit signature block tool for cleaner formatting.
                # If it used the LLM, the LLM probably copied the structure text. 
                # We will just append the block. It's safer.
                # full_structure.append({"type": "paragraph", "text": "Date:"})
                full_structure.append({"type": "signature_block", "guide": context.get("guide"), "hod": context.get("hod"), "department": context.get("department")})
                full_structure.append({"type": "page_break", "text": ""})

                # Acknowledgement
                full_structure.append({"type": "title", "text": "ACKNOWLEDGEMENT"})
                ack_text = gen.fill_template("Acknowledgement", context)
                full_structure.append({"type": "paragraph", "text": ack_text})
                
                # Abstract
                full_structure.append({"type": "section_header", "text": "ABSTRACT"})
                # Basic abstract generation
                abs_prompt = f"Generate a formal 200-word abstract for a B.Tech project titled '{context.get('title')}'. Problem: {context.get('problem_statement')}"
                try:
                    abstract_text = gen.generate_section("Abstract", summary.to_json(), context) # Reusing generic generator or custom prompt
                except:
                   abstract_text = "Abstract content goes here."
                full_structure.append({"type": "paragraph", "text": abstract_text})

                # List of Figures & Tables (Placeholders)
                full_structure.append({"type": "section_header", "text": "List of Figures"})
                full_structure.append({"type": "paragraph", "text": "\n[List of Figures will be auto-generated here]\n"})
                
                full_structure.append({"type": "section_header", "text": "List of Tables"})
                full_structure.append({"type": "paragraph", "text": "\n[List of Tables will be auto-generated here]\n"})
                full_structure.append({"type": "page_break", "text": ""}) # Explicit break before TOC

                # TOC — pass the schema so static TOC can list chapters
                full_structure.append({"type": "toc", "text": "Table of Contents", "schema": REPORT_SCHEMA})

                # 2. CHAPTERS GENERATION
                progress = st.progress(0)
                total_steps = sum(len(c["subsections"]) for c in REPORT_SCHEMA)
                current_step = 0

                for chapter_idx, chapter in enumerate(REPORT_SCHEMA):
                    chapter_num = chapter_idx + 1
                    full_structure.append({"type": "chapter", "text": chapter["title"]})
                    
                    for sub_idx, sub_title in enumerate(chapter["subsections"]):
                        st.write(f"Writing {chapter['title']} > {sub_title}...")
                        
                        # Call Generator loop
                        body_text = gen.generate_subsection_body(chapter["title"], sub_title, summary.to_json(), context)
                        
                        full_structure.append({"type": "subheading", "text": sub_title})
                        full_structure.append({"type": "paragraph", "text": body_text})
                        
                        current_step += 1
                        progress.progress(min(current_step / total_steps, 1.0))
                        time.sleep(1) 

                # 3. REFERENCES PAGE
                full_structure.append({"type": "section_header", "text": "References"})
                ref_text = (
                    "[1] Add your references here.\n\n"
                    "Note: Replace this placeholder with actual references used in your project. "
                    "Use the citation style specified by your university (IEEE, APA, etc.)."
                )
                full_structure.append({"type": "paragraph", "text": ref_text})

                # 4. RENDER
                st.success("Rendering DOCX...")
                buf = io.BytesIO()
                generate_report(full_structure, buf, style_name=sel_style)
                st.download_button("Download Final Report", buf.getvalue(), "Academic_Report.docx")
            
            except Exception as e:
                st.error(f"Failure: {e}")
                st.text(traceback.format_exc())
