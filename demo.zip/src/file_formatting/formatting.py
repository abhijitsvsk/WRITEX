from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement, ns

def add_table_of_contents(doc):
    r"""
    Inserts a real Word TOC field: { TOC \o "1-3" \h \z \u }
    """
    paragraph = doc.add_paragraph()
    run = paragraph.add_run()
    
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(ns.qn('w:fldCharType'), 'begin')

    instrText = OxmlElement('w:instrText')
    instrText.set(ns.qn('xml:space'), 'preserve')
    instrText.text = 'TOC \\o "1-3" \\h \\z \\u'

    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(ns.qn('w:fldCharType'), 'separate')

    fldChar3 = OxmlElement('w:fldChar')
    fldChar3.set(ns.qn('w:fldCharType'), 'end')

    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)
    run._r.append(fldChar3)


def generate_report(structure, output_path, style_name="Standard", 
                    custom_font=None, custom_size=None, custom_spacing=None):
    doc = Document()

    # --- Standard Style Config ---
    font_name = "Times New Roman"
    font_size = 12
    line_spacing = 1.5
    
    # --- Margin Setup ---
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1.5) # Academic standard
    section.right_margin = Inches(1)

    # --- Hierarchy Counters ---
    # These strictly track where we are in the document
    counters = {"chapter": 0, "sub": 0, "subsub": 0, "figure": 0}
    
    # Trackers for dynamic lists
    figure_list = []
    lof_paragraph_placeholder = None
    lot_paragraph_placeholder = None

    for item in structure:
        itype = item.get("type")
        text = item.get("text", "")

        # 1. CHAPTER (Level 1)
        if itype == "chapter":
            counters["chapter"] += 1
            counters["sub"] = 0
            counters["subsub"] = 0
            
            doc.add_page_break()
            p = doc.add_paragraph()
            p.style = doc.styles['Heading 1']
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # "Chapter X: Title"
            run = p.add_run(f"CHAPTER {counters['chapter']}\n{text.upper()}")
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(16)
            run.font.color.rgb = RGBColor(0, 0, 0)
            
            p.paragraph_format.space_after = Pt(24)

        # 2. SUBHEADING (Level 2) - 1.1
        elif itype == "subheading":
            counters["sub"] += 1
            counters["subsub"] = 0
            
            prefix = f"{counters['chapter']}.{counters['sub']}"
            p = doc.add_paragraph()
            p.style = doc.styles['Heading 2']
            
            run = p.add_run(f"{prefix}  {text}")
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0, 0, 0)
            
            p.paragraph_format.space_before = Pt(18)
            p.paragraph_format.space_after = Pt(12)

        # 3. SUBSUBHEADING (Level 3) - 1.1.1
        elif itype == "subsubheading":
            counters["subsub"] += 1
            
            prefix = f"{counters['chapter']}.{counters['sub']}.{counters['subsub']}"
            p = doc.add_paragraph()
            p.style = doc.styles['Heading 3']
            
            run = p.add_run(f"{prefix}  {text}")
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(12)
            run.font.color.rgb = RGBColor(0, 0, 0)

        # 4. TITLE / SPLASH
        elif itype == "title":
            p = doc.add_paragraph(text)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.runs[0]
            if len(p.runs) == 0: run = p.add_run(text)
            run.font.size = Pt(22) # Slightly reduced from 24
            run.bold = True
            run.font.name = font_name
            run.font.color.rgb = RGBColor(0, 0, 0)
            p.paragraph_format.space_after = Pt(24)

        # 4b. SECTION HEADER (Unnumbered, New Page) - for Abstract, LOF, LOT, References
        elif itype == "section_header":
            doc.add_page_break()
            p = doc.add_paragraph()
            p.style = doc.styles['Heading 1']
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(text.upper())
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(16)
            run.font.color.rgb = RGBColor(0, 0, 0)
            p.paragraph_format.space_after = Pt(24)
            
        # 5. SIGNATURE BLOCK
        elif itype == "signature_block":
            guide = item.get("guide", "Guide")
            hod = item.get("hod", "HOD")
            department = item.get("department", "")
            
            table = doc.add_table(rows=1, cols=2)
            table.autofit = True
            
            # Left Cell: Guide
            cell_l = table.cell(0, 0)
            p = cell_l.paragraphs[0]
            guide_text = f"\n\n\n___________________\n{guide}\nProject Guide"
            if department:
                guide_text += f"\nDepartment of {department}"
            run = p.add_run(guide_text)
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(11)
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            
            # Right Cell: HOD
            cell_r = table.cell(0, 1)
            p = cell_r.paragraphs[0]
            hod_text = f"\n\n\n___________________\n{hod}\nHead of Department"
            if department:
                hod_text += f"\nDepartment of {department}"
            run = p.add_run(hod_text)
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(11)
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT

        # 6. TOC — Static text-based listing with serial numbers
        elif itype == "toc":
            p = doc.add_paragraph()
            p.style = doc.styles['Heading 1']
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run("TABLE OF CONTENTS")
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(16)
            run.font.color.rgb = RGBColor(0, 0, 0)
            p.paragraph_format.space_after = Pt(18)
            
            # Generate static TOC entries from schema
            schema = item.get("schema", [])
            
            # Serial number counter
            serial = 1
            
            # Front matter entries (numbered dynamically based on what was generated before TOC)
            # Find all section_headers before TOC in the document run
            front_matter = []
            for prior_item in structure:
                if prior_item.get("type") == "toc":
                    break
                if prior_item.get("type") in ["title", "section_header"]:
                    title_text = prior_item.get("text", "")
                    if title_text.upper() not in ["Writex", "A PROJECT REPORT", "CERTIFICATE"]: # Exclude pure title page
                        front_matter.append(title_text)
            
            if not front_matter:
                 front_matter = ["Certificate", "Acknowledgement", "Abstract", "List of Figures", "List of Tables"]
            
            for fm_title in front_matter:
                p = doc.add_paragraph()
                run = p.add_run(f"{serial}.  {fm_title}")
                run.font.name = font_name
                run.font.size = Pt(font_size)
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.space_before = Pt(2)
                serial += 1
            
            # Chapter entries with subsections
            for ch_idx, chapter in enumerate(schema):
                ch_num = ch_idx + 1
                
                # Chapter title (numbered)
                p = doc.add_paragraph()
                run = p.add_run(f"{serial}.  Chapter {ch_num}: {chapter['title']}")
                run.bold = True
                run.font.name = font_name
                run.font.size = Pt(font_size)
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.space_before = Pt(4)
                serial += 1
                
                # Subsections
                for sub_idx, sub_title in enumerate(chapter.get("subsections", [])):
                    sub_num = sub_idx + 1
                    p = doc.add_paragraph()
                    p.paragraph_format.left_indent = Inches(0.5)
                    run = p.add_run(f"{ch_num}.{sub_num}  {sub_title}")
                    run.font.name = font_name
                    run.font.size = Pt(font_size)
                    p.paragraph_format.space_after = Pt(1)
                    p.paragraph_format.space_before = Pt(1)
            
            # References entry
            p = doc.add_paragraph()
            run = p.add_run(f"{serial}.  References")
            run.bold = True
            run.font.name = font_name
            run.font.size = Pt(font_size)
            p.paragraph_format.space_before = Pt(4)
            
            # Also insert hidden Word TOC field (updates on Ctrl+A, F9 in Word)
            add_table_of_contents(doc)
            
            doc.add_page_break()
            
        # 7. PAGE BREAK
        elif itype == "page_break":
            doc.add_page_break()

        # 8. PARAGRAPH / BODY / PLACEHOLDERS
        else: 
            text = text.strip()
            if not text: continue # Skip completely empty paragraphs
            
            # Check for specific auto-generate placeholders
            if "[List of Figures will be auto-generated here]" in text:
                 lof_paragraph_placeholder = doc.add_paragraph()
                 continue
            if "[List of Tables will be auto-generated here]" in text:
                 lot_paragraph_placeholder = doc.add_paragraph()
                 continue
                 
            if text.startswith("[Figure") or text.startswith("Figure"):
                 counters["figure"] += 1
                 fig_num = f"{counters['chapter']}.{counters['figure']}"
                 # Ensure standard prefixing
                 if not text.lower().startswith("figure"):
                     display_text = f"Figure {fig_num}: " + text.replace("[Figure", "").replace("]", "").strip()
                 else:
                     # If model outputs "Figure 1: blah", override with strictly correct numbering
                     import re
                     display_text = re.sub(r'^Figure [0-9.]+[:\-]?\s*', f"Figure {fig_num}: ", text)
                     
                 p = doc.add_paragraph(display_text)
                 p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                 figure_list.append(display_text)
                 
                 for run in p.runs:
                     run.italic = True
                     run.font.size = Pt(11)
            else:
                p = doc.add_paragraph(text)
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                p.paragraph_format.space_after = Pt(12)
                p.paragraph_format.line_spacing = line_spacing
                
                for run in p.runs:
                    run.font.name = font_name
                    run.font.size = Pt(font_size)

    # --- POST-PROCESSING ---
    # Fill List of Figures if placeholder exists
    if lof_paragraph_placeholder is not None:
         if not figure_list:
              lof_paragraph_placeholder.text = "No figures in this report."
         else:
              for fig in figure_list:
                   run = lof_paragraph_placeholder.add_run(fig + "\n")
                   run.font.name = font_name
                   run.font.size = Pt(font_size)

    _add_page_numbers(doc, font_name)
    
    # Save
    if hasattr(output_path, 'write'):
        doc.save(output_path)
    else:
        doc.save(output_path)

def _add_page_numbers(doc, font_name):
    # Simple footer page num
    section = doc.sections[0]
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.font.name = font_name
    
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(ns.qn('w:fldCharType'), 'begin')
    
    instrText = OxmlElement('w:instrText')
    instrText.set(ns.qn('xml:space'), 'preserve')
    instrText.text = "PAGE"
    
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(ns.qn('w:fldCharType'), 'end')
    
    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)
