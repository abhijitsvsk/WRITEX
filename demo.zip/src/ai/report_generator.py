import os
import json
import re
from typing import Dict, Any, List
from groq import Groq
from .utils import generate_with_retry
from .code_analysis_formatter import format_detailed_analysis_for_prompt
import textwrap

class ReportGenerator:
    def __init__(self, api_key: str, model_name: str = "llama-3.3-70b-versatile"):
        if not api_key:
             raise ValueError("API Key is required for ReportGenerator")
        # Initialize Groq client
        self.model = Groq(api_key=api_key)
        self.model_name = model_name

    def extract_metadata_from_sample(self, sample_text: str) -> Dict[str, str]:
        """
        Extracts structural and entity metadata from a sample report using LLM.
        """
        if not sample_text:
            return {}
            
        prompt = f"""
        Analyze the following academic report sample and extract these specific metadata fields if they exist.
        Return ONLY a JSON object with these exact keys:
        - "title": The project title
        - "team_names": A list of student names (if single, a list of 1)
        - "guide": The name of the project guide/supervisor
        - "hod": The Head of Department name
        - "principal": The Principal name
        - "university": The parent university name
        - "department": The department name (e.g., Computer Science and Engineering)
        - "degree": The degree title (e.g., Bachelor of Technology)
        - "academic_year": The academic year (e.g., 2025-2026)
        
        If a field is not found, leave its value as null or an empty string. Output ONLY valid JSON.
        
        Sample Text:
        \"\"\"
        {sample_text[:4000]} # Limit to first 4000 chars (mostly front matter)
        \"\"\"
        """
        try:
            response = generate_with_retry(self.model, prompt)
            import re
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
            return json.loads(response)
        except Exception as e:
            print(f"Metadata extraction failed: {e}")
            return {}

    def generate_section(self, section_name: str, project_summary: Dict[str, Any], user_context: Dict[str, Any]) -> str:
        """
        Generates content for a specific report section.
        """
        # Strict Templates for Cert/Ack
        if section_name.lower() in ["certificate", "acknowledgement", "acknowledgment"]:
             return self.fill_template(section_name, user_context)
             return self.fill_template(section_name, user_context)

        prompt = self._build_prompt(section_name, project_summary, user_context)
        
        try:
            return generate_with_retry(self.model, prompt)
        except Exception as e:
            return f"Error generating section {section_name}: {str(e)}"

    def generate_subsection_body(self, chapter_title: str, subsection_title: str, project_summary: Dict, user_context: Dict) -> str:
        """
        Generates ONLY the body text for a specific subsection.
        Strictly forbids outputting headings or markdown titles.
        """
        # CRITICAL: Special handling for Results chapter without test data
        if chapter_title == "Results and Discussion" and not user_context.get("has_test_files", False):
            # Provide honest fallback instead of fabricated metrics
            if "Performance Metrics" in subsection_title or "Experimental Output" in subsection_title:
                return """Testing and validation were performed through manual verification during development. Automated unit tests and performance benchmarking are planned for future iterations. Preliminary functionality testing confirms that the system meets its core requirements."""
            elif "Results Analysis" in subsection_title:
                return """The system was validated manually to ensure correctness of core functionality. Each module was tested individually before integration. While automated testing infrastructure is under development, the current implementation has been verified to work as specified in the requirements."""
        
        # Context Slicing
        sliced_summary = self._slice_context(chapter_title, project_summary)
        
        prompt = f"""
        You are an expert academic technical writer.
        
        Project Data:
        {json.dumps(sliced_summary, indent=2)}
        
        Context:
        Title: {user_context.get('title')}
        Problem: {user_context.get('problem_statement')}
        
        Task: Write the body text for the subsection: **"{subsection_title}"** (inside Chapter: "{chapter_title}").
        
        STRICT RULES:
        1. **NO HEADINGS**: Do NOT output markdown headings (no #, ##). Write ONLY paragraphs of text.
        2. **Specificity**: Reference specific modules/algorithms from the Project Data.
        3. **No Fluff**: No "game-changing", "cutting-edge". Be dry, distinct, and technical.
        4. **Length**: 2-3 detailed paragraphs (approx 200-300 words).
        5. **NO FABRICATION**: 
           - DO NOT invent metrics (accuracy, precision, recall, F1 score, execution time)
           - DO NOT create fake citations or placeholder references like [Class Ref] or [Standard Ref]
           - DO NOT claim experimental results without explicit data
           - If you need to reference a concept, describe it without citing fake sources
           - Only describe what is verifiable from the provided Project Data
        """
        
        try:
            return generate_with_retry(self.model, prompt)
        except Exception as e:
            return f"Error generating {subsection_title}: {str(e)}"

    def fill_template(self, section_name: str, user_context: Dict) -> str:
        """
        Refills a template or sample text with user details, strictly preserving structure.
        """
        # 1. Try to get raw text from sample if available
        base_text = ""
        sample_sections = user_context.get("sample_sections", {})
        
        # Normalize key lookup
        key_map = {
            "Certificate": "certificate",
            "certificate": "certificate",
            "Acknowledgement": "acknowledgement",
            "acknowledgement": "acknowledgement",
            "acknowledgment": "acknowledgement",
            "Acknowledgment": "acknowledgement"
        }
        sample_key = key_map.get(section_name)
        
        if sample_key and sample_sections.get(sample_key):
             base_text = sample_sections.get(sample_key)
             # If the sample text is very short (likely failed extraction), fallback
             # Lowering threshold to 20 to allow short but valid sections
             if len(base_text) < 20: 
                 base_text = ""

        # Default Strict Templates (Fallback)
        if not base_text:
            if section_name == "Certificate":
                base_text = textwrap.dedent("""
                CERTIFICATE

                This is to certify that the project report entitled "{title}" submitted by {student_name} in partial fulfillment of the requirements for the award of the degree of {degree} is a bona fide record of the work carried out under my supervision.

                _________________________           _________________________
                Signature of Guide                  Signature of HOD
                {guide}                        {hod}
                """).strip()
            elif section_name == "Acknowledgement":
                base_text = textwrap.dedent("""
                ACKNOWLEDGEMENT

                I would like to express my deep sense of gratitude to my guide, {guide}, for their valuable guidance and supervision throughout this project.
                
                I also thank the Head of the Department, {hod}, and the faculty members for their support.
                
                Finally, I thank my parents and friends for their encouragement.

                {student_name}
                """).strip()
            else:
                return f"Error: No template for {section_name}"
        
        # 2. Variable Replacement
        # We need to be careful with sample text. It might contain hardcoded names from the sample.
        # We will try to replace common placeholders if they exist in the sample, 
        # BUT since we don't know the exact string to replace in the sample (e.g. "REV. DR. JAISON"), 
        # we will assume the user wants the SAMPLE STRUCTURE but with THEIR details inserted where appropriate.
        #
        # COMPLEXITY: We can't easily find "Fayas Asis" to replace with "{student_name}" without named entity recognition.
        # However, for a "Strict" mode as requested by user, if they provide a sample, they often want THAT exact text.
        #
        # IMPROVEMENT: If we use the sample text verbatim, it will contain the OLD names.
        # We must try to ask the LLM to "rewrite this sample text with these new details" to match the style perfectly.
        # This is safer than regex for unstructured sample text.
        
        # CRITICAL: Acknowledgement & Certificate Strict Templates
        if sample_key == "acknowledgement":
            # Prepare variables
            principal = user_context.get('principal') or 'the Principal'
            hod = user_context.get('hod') or 'the HOD'
            guide = user_context.get('guide', '') or 'the Guide'
            university = user_context.get('university', '') or 'the University'
            department = user_context.get('department', '') or 'the Department'
            
            # Handle string or list naturally
            raw_names = user_context.get('student_name', '')
            if isinstance(raw_names, list):
                student_names_list = raw_names
            else:
                student_names_list = str(raw_names).split('\n')
            
            print(f"DEBUG: Acknowledgement Generation - Received Student Names: {student_names_list}")
            
            clean_names = [n.strip() for n in student_names_list if n.strip()]
            if not clean_names:
                formatted_team = "[TEAM MEMBERS NAMES MISSING - PLEASE ENTER IN SIDEBAR]"
            else:
                formatted_team = "\n".join(clean_names)
            
            # Pronoun logic: single student = I/my, team = We/our
            mode = user_context.get('pronoun_mode')
            if not mode:
                 mode = "singular" if len(clean_names) <= 1 else "plural"
                 
            if mode == "singular":
                we_lower = "i"
                We, our, us, Our = "I", "my", "me", "My"
            else:
                we_lower = "we"
                We, our, us, Our = "We", "our", "us", "Our"
            
            # The strict template — uses user's actual university and department
            text = textwrap.dedent(f"""
            {We} wish to express {our} sincere gratitude towards {principal}, Principal of {university}, and {hod}, Head of the Department of {department}, for providing {us} with the opportunity to undertake {our} project, "{user_context.get('title')}".

            It is indeed {our} pleasure and a moment of satisfaction to express {our} sincere gratitude to {our} project guide, {guide}, for the patience and all the priceless advice and wisdom shared with {us} throughout the duration of this project.

            {We} would also like to thank the faculty members of the Department of {department} for their valuable support and suggestions.

            Last but not the least, {we_lower} would like to express {our} sincere gratitude towards {our} parents and friends for their continuous support and constructive ideas.
            
            {formatted_team}
            """).strip()
            
            return text
            
            return text
        
        if sample_key == "certificate" and base_text:
            # For Certificate, use LLM to swap entities in sample text
            prompt = f"""
            Task: You are a text processing engine. The user has provided a specific {section_name} text.
            Your satisfying criteria:
            1. OUTPUT the provided text EXACTLY as is, word-for-word as much as possible, retaining its strict layout.
            2. ONLY replace the specific project details (Title, Guide, HOD, University).
            3. DO NOT rewrite the sentence structure.
            4. **CRITICAL**: The original text contains a list of old student names. **REPLACE that entire list** with the new list of names provided below:
               "{user_context.get('student_name')}"
            5. Ensure grammar aligns (e.g. "record of the work done by [Student Names]" instead of old names). If single student use 'is', if plural use 'are'.
            6. DO NOT add any conversational text.
            
            Original Sample Text:
            \"\"\"
            {base_text}
            \"\"\"
            
            New Details to Insert (Use these ONLY for the corresponding fields in the text):
            - Project Title: {user_context.get('title')}
            - Degree: {user_context.get('degree')}
            - Guide Name: {user_context.get('guide', 'Guide')}
            - HOD Name: {user_context.get('hod', 'HOD')}
            - University: {user_context.get('university', 'University')}
            
            OUTPUT ONLY THE FINAL TEXT.
            """
            try:
                return generate_with_retry(self.model, prompt)
            except:
                return base_text # Fallback to original if LLM fails

        # 3. Fallback Replacement for default templates
        replacements = {
            "{title}": user_context.get('title', '[Project Title]'),
            "{student_name}": user_context.get('student_name', '[Student Name]'),
            "{degree}": user_context.get('degree', 'Bachelor of Technology'),
            "{guide}": user_context.get('guide', '[Guide Name]'),
            "{hod}": user_context.get('hod', '[HOD Name]')
        }
        
        text = base_text
        for key, val in replacements.items():
            text = text.replace(key, str(val))
            
        return text

    def generate_literature_survey_body(self, project_summary: Dict, user_context: Dict) -> str:
        """
        Generates body paragraphs for Lit Survey.
        """
        sliced_summary = {
            "tech_stack": project_summary.get("tech_stack"),
            "modules": (project_summary.get("modules") or [])[:5]
        }
        
        prompt = f"""
        Task: Write a comparative literature survey body text (3-4 paragraphs).
        
        Context:
        {json.dumps(sliced_summary, indent=2)}
        
        Requirements:
        1. Compare 3 distinct standard approaches relevant to this tech stack.
        2. For each, state the **Limitation** (Technical bottleneck).
        3. State how THIS project proposes to solve it.
        4. **NO FAKE CITATIONS**. Use phrases like "Standard implementations of X typically suffer from..." or "Smith et al. (2020) proposed..." only if you are 100% sure it exists. Otherwise adhere to general technical consensus.
        5. NO HEADINGS. Just body text.
        """
        try:
            return generate_with_retry(self.model, prompt)
        except Exception as e:
            return f"Error generating survey: {e}"

    def derive_project_context(self, project_summary: Dict) -> Dict[str, str]:
        # Remove detailed_analysis before json.dumps (it's not JSON serializable)
        summary_for_json = {k: v for k, v in project_summary.items() if k != "detailed_analysis"}
        
        # ... (Keep existing simple context derivation, it works fine) ...
        prompt = f"""
        Analyze this project:
        {json.dumps(summary_for_json, indent=2)[:2000]}
        
        Generate concise:
        1. Problem Statement (Technical, 2 sentences).
        2. Key Objectives (3 bullet points).
        
        Return JSON: {{ "problem_statement": "...", "objectives": "..." }}
        """
        try:
            text = generate_with_retry(self.model, prompt)
            import re
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match: return json.loads(json_match.group(0))
            return json.loads(text)
        except:
             return {"problem_statement": "Technical efficiency issue.", "objectives": "- Optimize workflow.\n- Automate data."}

    def _build_prompt(self, section_name: str, project_summary: Dict, user_context: Dict) -> str:
        # CRITICAL: Extract detailed code analysis if available (stored in user_context, not project_summary)
        detailed_analysis = user_context.get("detailed_analysis")
        real_code_section = ""
        
        if detailed_analysis:
            # Format the detailed analysis for injection
            real_code_section = f"\n\n=== REAL CODE ANALYSIS ===\n{format_detailed_analysis_for_prompt(detailed_analysis)}\n"
            real_code_section += "\nIMPORTANT: Use ONLY the functions, classes, and patterns listed above. Do NOT invent code that doesn't exist.\n"
        
        # Context Slicing specific to section
        sliced_summary = {}
        section_lower = section_name.lower()
        
        if "abstract" in section_lower or "introduction" in section_lower:
            sliced_summary = {
                "project_type": project_summary.get("project_type"),
                "problem_statement": user_context.get("problem_statement"), 
                "objectives": user_context.get("objectives"), 
                "tech_stack": (project_summary.get("tech_stack") or [])[:5] 
            }
        elif "methodology" in section_lower or "implementation" in section_lower:
            # Pass ALL extracted modules for deep context, including classes/functions
            sliced_summary = {
                "tech_stack": project_summary.get("tech_stack") or [],
                "algorithms": project_summary.get("algorithms_used") or [],
                "modules": project_summary.get("modules") or [], 
                "workflow": project_summary.get("workflow") or ""
            }
        elif "results" in section_lower or "discussion" in section_lower:
             sliced_summary = {
                "problem_statement": user_context.get("problem_statement"),
                "objectives": user_context.get("objectives"),
            }
        else:
            # Default fallback
            sliced_summary = {k: v for k, v in project_summary.items() if k in ["project_type", "tech_stack", "algorithms_used"]}

        style_instruction = ""
        if user_context.get("style_guide"):
             style_instruction = f"IMPORTANT: Follow this writing style:\n{user_context.get('style_guide')[:1500]}"

        base_prompt = f"""
        You are an academic report writer for a {user_context.get('degree', 'Computer Science')} project.
        
        {style_instruction}
        
        Project Analysis:
        {json.dumps(sliced_summary, indent=2)}
        {real_code_section}
        
        User Context:
        Title: {user_context.get('title')}
        Problem: {user_context.get('problem_statement')}
        Objectives: {user_context.get('objectives')}
        
        Task: Write the **{section_name}** section.
        
        Guidelines:
        - Academic tone, passive voice.
        - Reference specific classes/functions from modules if available.
        - Length: Comprehensive (approx 300-500 words).
        """
        return base_prompt

    def _slice_context(self, chapter_title: str, project_summary: Dict) -> Dict:
        # Helper to slice context based on chapter
        full_summary = project_summary
        title = chapter_title.lower()
        
        if "intro" in title:
            return {"project_type": full_summary.get("project_type"), "tech_stack": full_summary.get("tech_stack")}
        elif "method" in title or "implement" in title:
             return {"modules": full_summary.get("modules"), "algorithms": full_summary.get("algorithms_used"), "workflow": full_summary.get("workflow")}
        elif "result" in title:
             return {"project_type": full_summary.get("project_type")}
        return {"tech_stack": full_summary.get("tech_stack")}
